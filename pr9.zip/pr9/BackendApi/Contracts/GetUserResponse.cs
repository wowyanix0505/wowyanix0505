﻿namespace BackendApi.Contracts
{
    public class GetUserResponse
    {
    }
}
